# Sistema de Recomendação de Produtos com Neo4j

Projeto prático de banco de dados em grafos desenvolvido com **Neo4j e Cypher**. O objetivo é representar clientes, produtos e categorias, explorar as conexões entre eles e produzir recomendações simples com base no histórico de compras.

> Projeto educacional com dados fictícios. Os arquivos foram preparados para execução no Neo4j Aura ou Neo4j Desktop.

## Problema

Em uma loja virtual, recomendações baseadas apenas em tabelas podem exigir consultas com vários relacionamentos entre clientes, compras, produtos e categorias. Um banco de dados em grafos representa essas conexões diretamente, tornando a navegação entre entidades intuitiva.

## Por que Neo4j?

- Clientes, produtos e categorias são representados como nós.
- Compras e classificações são representadas como relacionamentos.
- O Cypher permite descrever padrões de conexão de forma legível.
- É possível encontrar produtos comprados por clientes com interesses semelhantes.

## Modelo de dados

![Modelo do grafo](imagens/modelo-grafo.svg)

### Nós

| Label | Propriedades principais |
|---|---|
| `Cliente` | `id`, `nome`, `cidade` |
| `Produto` | `id`, `nome`, `preco` |
| `Categoria` | `id`, `nome` |

### Relacionamentos

| Relacionamento | Direção | Propriedades |
|---|---|---|
| `COMPROU` | Cliente → Produto | `data`, `quantidade` |
| `PERTENCE_A` | Produto → Categoria | — |
| `INTERESSADO_EM` | Cliente → Categoria | `origem` |

## Estrutura do repositório

```text
projeto-neo4j-recomendacao-produtos/
├── README.md
├── data/
│   ├── clientes.csv
│   ├── produtos.csv
│   └── categorias.csv
├── queries/
│   ├── 01_criacao_nos.cypher
│   ├── 02_relacionamentos.cypher
│   ├── 03_consultas.cypher
│   └── 04_atualizacoes_e_exclusoes.cypher
└── imagens/
    └── modelo-grafo.svg
```

## Tecnologias

- Neo4j
- Cypher Query Language
- CSV
- Git e GitHub

## Como executar

### Opção A — Neo4j Aura

1. Crie uma instância gratuita no [Neo4j Aura](https://neo4j.com/cloud/aura/).
2. Abra o Neo4j Query e conecte-se à instância.
3. Baixe os três CSVs da pasta `data/` e hospede-os em um endereço HTTPS público (por exemplo, em um repositório GitHub público).
4. Abra `queries/01_criacao_nos.cypher`.
5. Substitua os endereços `https://SEU-USUARIO.github.io/SEU-REPOSITORIO/data/` pelos endereços públicos correspondentes dos CSVs.
6. Execute o script de criação dos nós.
7. Execute `02_relacionamentos.cypher`, `03_consultas.cypher` e, por último, `04_atualizacoes_e_exclusoes.cypher` conforme desejar.

### Opção B — Neo4j Desktop

1. Crie um projeto e uma instância local.
2. Inicie a instância e abra o Neo4j Browser.
3. Copie os CSVs para a pasta `import` da instância.
4. No script `01_criacao_nos.cypher`, use os caminhos `file:///clientes.csv`, `file:///produtos.csv` e `file:///categorias.csv` (as linhas com URL HTTPS podem ser substituídas pelos caminhos locais).
5. Execute os scripts na ordem indicada acima.

> **Importante:** `LOAD CSV` lê os arquivos a partir do servidor Neo4j. No Aura, o arquivo precisa estar hospedado em uma URL acessível publicamente. No Desktop, ele pode ficar na pasta `import` da instância.

## Consultas de negócio

O arquivo `queries/03_consultas.cypher` contém exemplos para responder perguntas como:

1. Quais produtos cada cliente comprou?
2. Quais produtos pertencem a cada categoria?
3. Quais clientes compraram um produto específico?
4. Quais produtos podem ser recomendados a um cliente com base nas compras de clientes que também compraram os mesmos itens?

## Atualização e exclusão

O arquivo `queries/04_atualizacoes_e_exclusoes.cypher` demonstra `SET`, `REMOVE`, `DELETE` e `DETACH DELETE`. As operações destrutivas estão comentadas para evitar apagar dados acidentalmente. Execute-as somente em ambiente de teste.

## Evidências visuais

Após executar os scripts:

1. Execute `CALL db.schema.visualization()` para visualizar o esquema.
2. Execute a consulta de exploração no arquivo `03_consultas.cypher`.
3. Tire capturas de tela do Neo4j Browser ou Explore.
4. Salve as imagens nesta pasta `imagens/`, por exemplo `schema-neo4j.png` e `consulta-recomendacao.png`.
5. Atualize esta seção do README com as capturas reais obtidas no seu ambiente.

As capturas não foram simuladas neste pacote: elas devem ser geradas após a execução no seu Neo4j.

## Dificuldades comuns (troubleshooting)

- **CSV não encontrado:** confirme que o arquivo está na pasta `import` (Desktop) ou em uma URL HTTPS pública (Aura).
- **Erro de acesso ao CSV:** verifique se a URL abre sem autenticação e aponta diretamente para o conteúdo CSV.
- **Nós duplicados:** os scripts usam `MERGE` e identificadores `id` para evitar duplicações na carga.
- **Preço carregado como texto:** o script converte o campo com `toFloat()`.
- **Relacionamento duplicado:** a criação dos relacionamentos usa `MERGE`.
- **Não consigo excluir um nó:** no Neo4j, `DELETE` não remove um nó que ainda possui relacionamentos; use `DETACH DELETE` quando a intenção for remover também as relações.

## Próximas melhorias

- Criar constraints de unicidade para os identificadores.
- Adicionar avaliações e notas dos produtos.
- Criar uma API para consultar recomendações.
- Implementar recomendações com Neo4j Graph Data Science.
- Criar um dashboard para visualizar os resultados.

## Autor

**Seu nome aqui**

Projeto desenvolvido para fins de estudo e portfólio na trilha de banco de dados em grafos da DIO.
