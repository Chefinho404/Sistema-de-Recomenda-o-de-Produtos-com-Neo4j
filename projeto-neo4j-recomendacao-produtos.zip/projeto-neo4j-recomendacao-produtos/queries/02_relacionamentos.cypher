// Relaciona produtos às categorias usando o identificador da categoria.
MATCH (p:Produto), (cat:Categoria {id: p.categoria_id})
MERGE (p)-[:PERTENCE_A]->(cat);

// Histórico fictício de compras.
// MERGE evita criar a mesma relação quando o script é executado novamente.
MATCH (c:Cliente {id: 'C001'}), (p:Produto {id: 'P001'})
MERGE (c)-[r:COMPROU {data: date('2026-01-10')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C001'}), (p:Produto {id: 'P002'})
MERGE (c)-[r:COMPROU {data: date('2026-01-12')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C002'}), (p:Produto {id: 'P001'})
MERGE (c)-[r:COMPROU {data: date('2026-01-15')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C002'}), (p:Produto {id: 'P003'})
MERGE (c)-[r:COMPROU {data: date('2026-01-16')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C003'}), (p:Produto {id: 'P004'})
MERGE (c)-[r:COMPROU {data: date('2026-01-18')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C003'}), (p:Produto {id: 'P005'})
MERGE (c)-[r:COMPROU {data: date('2026-01-20')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C004'}), (p:Produto {id: 'P002'})
MERGE (c)-[r:COMPROU {data: date('2026-01-22')}]->(p)
SET r.quantidade = 2;

MATCH (c:Cliente {id: 'C004'}), (p:Produto {id: 'P003'})
MERGE (c)-[r:COMPROU {data: date('2026-01-23')}]->(p)
SET r.quantidade = 1;

MATCH (c:Cliente {id: 'C005'}), (p:Produto {id: 'P006'})
MERGE (c)-[r:COMPROU {data: date('2026-01-25')}]->(p)
SET r.quantidade = 1;

// Interesse explícito de exemplo, além do histórico de compras.
MATCH (c:Cliente {id: 'C001'}), (cat:Categoria {id: 'CAT01'})
MERGE (c)-[:INTERESSADO_EM {origem: 'cadastro'}]->(cat);
