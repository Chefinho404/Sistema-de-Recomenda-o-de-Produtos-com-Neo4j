// Antes de executar: substitua a URL base pela URL pública dos CSVs.
// Exemplo GitHub Pages: https://SEU-USUARIO.github.io/SEU-REPOSITORIO/data/

// Restrições de unicidade: podem ser executadas uma vez por banco.
CREATE CONSTRAINT cliente_id IF NOT EXISTS
FOR (c:Cliente) REQUIRE c.id IS UNIQUE;

CREATE CONSTRAINT produto_id IF NOT EXISTS
FOR (p:Produto) REQUIRE p.id IS UNIQUE;

CREATE CONSTRAINT categoria_id IF NOT EXISTS
FOR (cat:Categoria) REQUIRE cat.id IS UNIQUE;

// Clientes
LOAD CSV WITH HEADERS FROM
'https://SEU-USUARIO.github.io/SEU-REPOSITORIO/data/clientes.csv' AS row
MERGE (c:Cliente {id: row.id})
SET c.nome = row.nome,
    c.cidade = row.cidade;

// Categorias
LOAD CSV WITH HEADERS FROM
'https://SEU-USUARIO.github.io/SEU-REPOSITORIO/data/categorias.csv' AS row
MERGE (cat:Categoria {id: row.id})
SET cat.nome = row.nome;

// Produtos
LOAD CSV WITH HEADERS FROM
'https://SEU-USUARIO.github.io/SEU-REPOSITORIO/data/produtos.csv' AS row
MERGE (p:Produto {id: row.id})
SET p.nome = row.nome,
    p.preco = toFloat(row.preco),
    p.categoria_id = row.categoria_id;
