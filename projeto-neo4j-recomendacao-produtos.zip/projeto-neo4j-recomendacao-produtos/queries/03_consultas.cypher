// 1. Visualizar todos os clientes, compras e produtos.
MATCH (c:Cliente)-[r:COMPROU]->(p:Produto)
RETURN c, r, p;

// 2. Listar produtos e suas categorias.
MATCH (p:Produto)-[:PERTENCE_A]->(cat:Categoria)
RETURN p.nome AS produto, p.preco AS preco, cat.nome AS categoria
ORDER BY categoria, produto;

// 3. Histórico de compras de cada cliente.
MATCH (c:Cliente)-[r:COMPROU]->(p:Produto)
RETURN c.nome AS cliente, p.nome AS produto,
       r.quantidade AS quantidade, r.data AS data
ORDER BY cliente, data;

// 4. Clientes que compraram o Notebook.
MATCH (c:Cliente)-[:COMPROU]->(p:Produto {nome: 'Notebook'})
RETURN c.nome AS cliente, c.cidade AS cidade;

// 5. Recomendar produtos a Ana com base em clientes que compraram
// algum produto em comum. Exclui produtos que Ana já comprou.
MATCH (alvo:Cliente {id: 'C001'})-[:COMPROU]->(comum:Produto)
MATCH (outro:Cliente)-[:COMPROU]->(comum)
MATCH (outro)-[:COMPROU]->(recomendado:Produto)
WHERE alvo <> outro
  AND NOT (alvo)-[:COMPROU]->(recomendado)
RETURN recomendado.nome AS recomendacao,
       count(DISTINCT outro) AS clientes_em_comum
ORDER BY clientes_em_comum DESC, recomendacao;

// 6. Contagem de produtos por categoria.
MATCH (cat:Categoria)<-[:PERTENCE_A]-(p:Produto)
RETURN cat.nome AS categoria, count(p) AS total_produtos
ORDER BY total_produtos DESC;

// 7. Visualizar o esquema do banco.
CALL db.schema.visualization();
