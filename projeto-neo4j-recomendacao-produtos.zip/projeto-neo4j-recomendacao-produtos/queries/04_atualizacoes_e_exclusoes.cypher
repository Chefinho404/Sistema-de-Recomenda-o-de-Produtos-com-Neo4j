// SET: adicionar ou atualizar propriedades de um nó.
MATCH (c:Cliente {id: 'C001'})
SET c.email = 'ana.exemplo@email.com';

// SET: adicionar um label ao nó.
MATCH (c:Cliente {id: 'C001'})
SET c:ClienteAtivo;

// REMOVE: remover um label sem excluir o nó.
MATCH (c:Cliente {id: 'C001'})
REMOVE c:ClienteAtivo;

// DELETE: remover apenas um relacionamento (os nós permanecem).
// Execute separadamente se quiser testar:
// MATCH (:Cliente {id: 'C005'})-[r:COMPROU]->(:Produto {id: 'P006'})
// DELETE r;

// DETACH DELETE: excluir um nó e todos os relacionamentos ligados a ele.
// ATENÇÃO: operação destrutiva; execute somente em ambiente de teste.
// MATCH (c:Cliente {id: 'C005'})
// DETACH DELETE c;
